CCVisu applied to co-change visualization:

// 1.) Produce a CVS log file.
cvs log -Nb > project.log

// 2.) Extract co-change graph from CVS log file.
ccvisu.sh -informat CVS -i project.log -outformat RSF -o project.rsf

// 3.) Compute layout and show on screen.
ccvisu.sh -i project.rsf -minVert 1 -iter 200 -hideSource -outformat DISP

