ccvisu.sh -vertRepu -attrExp 2 -showEdges -annotAll -iter 300 -i simple-chain-20.rsf
