ccvisu.sh -i simple-3times2.rsf -minVert 10 -showEdges -annotAll -fontSize 24
