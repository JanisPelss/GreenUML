#!/bin/sh

java -Xmx768M ccvisu.CCVisu $*
