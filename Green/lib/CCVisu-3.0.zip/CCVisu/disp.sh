#! /bin/sh

java -Xmx768M ccvisu.CCVisu -outFormat DISP -inFormat LAY -minVert 2 -i $*
