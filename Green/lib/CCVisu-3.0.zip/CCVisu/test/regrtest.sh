#!/bin/sh

PROGRAM="java -ea -classpath ../bin ccvisu.CCVisu"
FAILTEXT="The following test failed: $PROGRAM "


TEST="-assert"
echo $PROGRAM $TEST
RESULT=`$PROGRAM $TEST | grep enabled`
[ -n "$RESULT" ] || echo $FAILTEXT $TEST

TEST="-i ../examples/compiler.rsf -outFormat RSF"
echo $PROGRAM $TEST
RESULT=`$PROGRAM $TEST | wc -c`
[ $RESULT -eq 39676 ] || echo $FAILTEXT $TEST

TEST="-inFormat RSF -i ../examples/rsf-example.rsf -outFormat RSF"
echo $PROGRAM $TEST
RESULT=`$PROGRAM $TEST | grep -v "^#" > tmp.log && diff ../examples/rsf-example.rsf tmp.log && echo OK`
[ $RESULT = "OK" ] || echo $FAILTEXT $TEST

TEST="-inFormat DOX -i ../examples/crocopat-2.1.4-dox/index.xml -outFormat RSF -o tmp.log -q"
echo $PROGRAM $TEST
RESULT=`$PROGRAM $TEST && diff ../examples/crocopat-2.1.4.rsf tmp.log | wc -l`
[ $RESULT -eq 4 ] || echo $FAILTEXT $TEST

TEST="-inFormat RSF -i ../examples/crocopat-2.1.rsf -initLayout ../examples/crocopat-2.1_annot.lay -iter 0 -hideSource -outFormat LAY -o tmp.log -q"
echo $PROGRAM $TEST
RESULT=`$PROGRAM $TEST && diff ../examples/crocopat-2.1_annot.lay tmp.log | wc -l`
[ $RESULT -eq 4 ] || echo $FAILTEXT $TEST

